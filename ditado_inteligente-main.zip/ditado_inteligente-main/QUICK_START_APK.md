# ⚡ Quick Start: Compilar APK em 5 Minutos

## ✅ Pré-requisitos (Instalados?)
- [ ] Java JDK 17+ (`java -version`)
- [ ] Android Studio (com SDK)
- [ ] Node.js + pnpm (`pnpm --version`)
- [ ] Variáveis `ANDROID_HOME` e `JAVA_HOME` configuradas

---

## 🚀 Compilação Rápida

### **macOS/Linux**
```bash
cd /caminho/para/voice_text_corrector
pnpm install
pnpm build
chmod +x build-apk-debug.sh
./build-apk-debug.sh
```

### **Windows (PowerShell)**
```powershell
cd C:\caminho\para\voice_text_corrector
pnpm install
pnpm build
cd android
gradlew.bat assembleDebug
```

---

## 📁 APK Gerado
```
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 📱 Instalar no Telefone

### **Via Script (macOS/Linux)**
```bash
./install-apk.sh
```

### **Via ADB Manual**
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

### **Via Arquivo**
1. Copie o APK para seu telefone
2. Abra o gerenciador de arquivos
3. Toque no arquivo para instalar

---

## 🎯 Testar
1. Abra "Ditado Inteligente" no telefone
2. Faça login
3. Toque no microfone
4. Fale: "Olá, como você está?"
5. Veja o texto transcrito e corrigido

---

## ❓ Problemas?
Veja `COMPILAR_APK_PASSO_A_PASSO.md` para solução de problemas detalhada.

**Tempo total esperado: 5-15 minutos** ⏱️
