# 🚀 Guia Completo: Compilar APK do Ditado Inteligente

## ⏱️ Tempo Total: ~30-45 minutos

---

## 📋 Pré-requisitos

Antes de começar, você precisa ter instalado em sua máquina:

### 1. **Node.js e npm/pnpm**
```bash
# Verificar se está instalado
node --version  # Deve ser v18+
npm --version   # ou pnpm --version
```

### 2. **Java Development Kit (JDK) 17+**
```bash
# Download: https://www.oracle.com/java/technologies/downloads/
# Ou use Homebrew (macOS):
brew install openjdk@17

# Verificar instalação
java -version
```

### 3. **Android Studio**
- Download: https://developer.android.com/studio
- Instale com as opções padrão
- Na primeira execução, deixe instalar os componentes Android SDK

### 4. **Gradle** (geralmente vem com Android Studio)
```bash
# Verificar
gradle --version
```

---

## 🔧 Configurar Variáveis de Ambiente

### **Windows (PowerShell como Admin)**
```powershell
# Abra PowerShell como Administrador e execute:
[Environment]::SetEnvironmentVariable("ANDROID_HOME", "C:\Users\SeuUsuario\AppData\Local\Android\Sdk", "User")
[Environment]::SetEnvironmentVariable("JAVA_HOME", "C:\Program Files\Java\jdk-17", "User")
[Environment]::SetEnvironmentVariable("PATH", "$env:PATH;$env:ANDROID_HOME\tools;$env:ANDROID_HOME\platform-tools", "User")

# Reinicie o PowerShell e verifique:
$env:ANDROID_HOME
```

### **macOS (Terminal)**
```bash
# Adicione ao ~/.zshrc ou ~/.bash_profile:
export ANDROID_HOME=$HOME/Library/Android/sdk
export JAVA_HOME=$(/usr/libexec/java_home -v 17)
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools

# Aplique as mudanças:
source ~/.zshrc
```

### **Linux (Terminal)**
```bash
# Adicione ao ~/.bashrc ou ~/.bash_profile:
export ANDROID_HOME=$HOME/Android/Sdk
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools

# Aplique as mudanças:
source ~/.bashrc
```

---

## 📥 Baixar e Preparar o Projeto

### 1. **Clone ou extraia o projeto**
```bash
# Se você tiver o arquivo compactado:
unzip voice_text_corrector.zip
cd voice_text_corrector
```

### 2. **Instale as dependências Node.js**
```bash
pnpm install
# Ou se usar npm:
npm install
```

### 3. **Compile o build de produção**
```bash
pnpm build
# Ou:
npm run build
```

---

## 🔨 Compilar o APK

### **Opção A: Usando o Script Automatizado (Recomendado)**

Se você está em **macOS ou Linux**, use o script que preparei:

```bash
# Torne o script executável
chmod +x build-apk-debug.sh

# Execute o script
./build-apk-debug.sh
```

O script fará automaticamente:
- ✅ Sincronizar Capacitor com Android
- ✅ Compilar com Gradle
- ✅ Gerar APK de debug
- ✅ Mostrar o caminho do APK gerado

---

### **Opção B: Compilação Manual (Windows, macOS, Linux)**

Se o script não funcionar ou você estiver no Windows, execute manualmente:

```bash
# 1. Sincronize o Capacitor com Android
npx cap sync android

# 2. Entre no diretório Android
cd android

# 3. Compile com Gradle (Debug)
./gradlew assembleDebug

# No Windows, use:
# gradlew.bat assembleDebug

# 4. Aguarde a compilação (pode levar 5-10 minutos na primeira vez)
```

---

## ✅ Onde Encontrar o APK

Após a compilação bem-sucedida, o APK estará em:

```
android/app/build/outputs/apk/debug/app-debug.apk
```

**Tamanho esperado:** ~50-80 MB

---

## 📱 Instalar no Telefone Android

### **Opção 1: Via USB (Recomendado)**

```bash
# Conecte seu telefone Android via USB
# Ative "Modo de Desenvolvedor" no telefone:
#   1. Configurações > Sobre o telefone
#   2. Toque 7 vezes em "Número de compilação"
#   3. Volte e ative "Opções de desenvolvedor"
#   4. Ative "Depuração USB"

# Instale o APK
adb install android/app/build/outputs/apk/debug/app-debug.apk

# Ou use o script:
./install-apk.sh
```

### **Opção 2: Via Arquivo (Transferência Manual)**

```bash
# Copie o arquivo para seu telefone via:
# - Google Drive
# - Email
# - Dropbox
# - Cabo USB

# No telefone:
# 1. Abra o gerenciador de arquivos
# 2. Localize o arquivo app-debug.apk
# 3. Toque para instalar
# 4. Confirme as permissões
```

### **Opção 3: Via QR Code**

```bash
# Hospede o APK em um servidor web:
python -m http.server 8000

# Acesse http://seu-ip:8000 no telefone
# Baixe e instale o APK
```

---

## 🐛 Solução de Problemas

### **Erro: "ANDROID_HOME não está definido"**
```bash
# Verifique se a variável está configurada:
echo $ANDROID_HOME  # macOS/Linux
echo %ANDROID_HOME%  # Windows

# Se não aparecer nada, configure novamente conforme acima
```

### **Erro: "Gradle não encontrado"**
```bash
# Certifique-se de estar no diretório do projeto
cd /caminho/para/voice_text_corrector

# Tente novamente:
cd android
./gradlew assembleDebug
```

### **Erro: "Java não encontrado"**
```bash
# Verifique a instalação do Java
java -version

# Se não funcionar, instale JDK 17:
# https://www.oracle.com/java/technologies/downloads/
```

### **Compilação muito lenta**
- Primeira compilação é sempre mais lenta (5-15 minutos)
- Próximas compilações são mais rápidas (1-3 minutos)
- Certifique-se de ter pelo menos 4GB de RAM disponível

### **APK não instala no telefone**
```bash
# Verifique se o telefone tem espaço suficiente
# Desinstale versões antigas:
adb uninstall com.ditadointeligente

# Tente instalar novamente:
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 🎯 Testar o Aplicativo

Após instalar, teste:

1. ✅ **Abra o app** - Deve mostrar "Ditado Inteligente"
2. ✅ **Selecione idioma** - Português/English/Español
3. ✅ **Toque no microfone** - Deve começar a gravar
4. ✅ **Fale algo** - "Olá, como você está?"
5. ✅ **Parar gravação** - Clique no ícone vermelho
6. ✅ **Veja resultado** - Texto transcrito e corrigido
7. ✅ **Tema escuro** - Mude preferência do sistema Android

---

## 📦 Gerar APK Assinado (Opcional - Para Distribuição)

Se quiser distribuir o app na Google Play Store:

```bash
# 1. Crie uma chave de assinatura (uma única vez)
keytool -genkey -v -keystore ditado-inteligente.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias ditado-inteligente

# 2. Configure em android/app/build.gradle (adicione ao final):
signingConfigs {
    release {
        storeFile file('../../ditado-inteligente.jks')
        storePassword 'sua-senha'
        keyAlias 'ditado-inteligente'
        keyPassword 'sua-senha'
    }
}

# 3. Compile APK assinado
cd android
./gradlew assembleRelease

# O APK estará em:
# android/app/build/outputs/apk/release/app-release.apk
```

---

## 🎉 Sucesso!

Seu APK está pronto! Agora você pode:
- ✅ Testar no seu telefone Android 15/16
- ✅ Compartilhar com amigos
- ✅ Distribuir na Google Play Store (com APK assinado)
- ✅ Fazer melhorias e recompilar

---

## 📞 Precisa de Ajuda?

Se encontrar problemas:
1. Verifique se todos os pré-requisitos estão instalados
2. Leia a seção "Solução de Problemas" acima
3. Verifique os logs de erro da compilação
4. Tente compilar novamente após reiniciar o computador

**Boa sorte! 🚀**
