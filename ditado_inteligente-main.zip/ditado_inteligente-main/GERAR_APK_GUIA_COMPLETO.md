# Guia Completo: Gerar APK Instalável do Ditado Inteligente

## 📱 Visão Geral

Este guia fornece instruções passo-a-passo para gerar um arquivo APK que pode ser instalado em qualquer telefone Android 15 ou 16.

---

## 🚀 Opção 1: APK de Debug (Teste Rápido)

Use esta opção para testar o aplicativo em seu telefone rapidamente.

### Pré-requisitos

1. **Android Studio** instalado em seu computador
   - Download: https://developer.android.com/studio
   - Versão mínima: Dolphin ou mais recente

2. **Java Development Kit (JDK)** 11 ou superior
   - Geralmente instalado automaticamente com Android Studio

3. **Android SDK** configurado
   - Android Studio instala automaticamente

### Passos

#### 1. Clonar o Projeto (Se Necessário)

```bash
# Se você ainda não tem o projeto localmente
git clone <seu-repositorio> voice_text_corrector
cd voice_text_corrector
```

#### 2. Instalar Dependências

```bash
# Instalar dependências Node.js
pnpm install

# Compilar o build de produção
pnpm build

# Sincronizar com Capacitor
npx cap sync android
```

#### 3. Abrir no Android Studio

```bash
# Abrir o projeto Android no Android Studio
npx cap open android
```

Isso abrirá automaticamente o Android Studio com o projeto Android configurado.

#### 4. Compilar APK de Debug

No Android Studio:

1. Vá para **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
2. Aguarde a compilação (pode levar 2-5 minutos)
3. Uma notificação aparecerá: "Build successful"
4. Clique em **Locate** para encontrar o arquivo APK

**Localização do arquivo:**
```
android/app/build/outputs/apk/debug/app-debug.apk
```

#### 5. Instalar no Telefone

**Via Android Studio (Recomendado):**
1. Conecte seu telefone Android via USB
2. Ative "Depuração USB" nas configurações do desenvolvedor
3. No Android Studio, clique em **Run** → **Run 'app'**
4. Selecione seu dispositivo
5. O aplicativo será instalado automaticamente

**Via Arquivo APK (Manual):**
1. Copie o arquivo `app-debug.apk` para seu telefone
2. Abra um gerenciador de arquivos no telefone
3. Localize o arquivo APK
4. Toque para instalar
5. Permita a instalação de fontes desconhecidas se solicitado

---

## 🔐 Opção 2: APK Assinado (Produção)

Use esta opção para distribuir o aplicativo na Google Play Store ou compartilhar com outros usuários.

### Pré-requisitos

- Tudo da Opção 1
- Chave de assinatura (keystore)

### Passos

#### 1. Criar Chave de Assinatura (Se Não Tiver)

```bash
# Navegar para a pasta android/app
cd android/app

# Gerar chave de assinatura
keytool -genkey -v -keystore ditado-inteligente.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias ditado-inteligente-key
```

**Informações Solicitadas:**
- Senha do keystore: `sua_senha_segura`
- Nome completo: `Seu Nome`
- Unidade organizacional: `Seu Departamento`
- Organização: `Sua Empresa`
- Cidade: `Sua Cidade`
- Estado: `Seu Estado`
- Código do país: `BR`

**Salve a senha em local seguro!**

#### 2. Configurar Gradle para Assinatura

Edite `android/app/build.gradle`:

```gradle
android {
    signingConfigs {
        release {
            storeFile file('ditado-inteligente.keystore')
            storePassword 'sua_senha_segura'
            keyAlias 'ditado-inteligente-key'
            keyPassword 'sua_senha_segura'
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

#### 3. Compilar APK Assinado

No Android Studio:

1. Vá para **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
2. Ou via terminal:

```bash
cd android
./gradlew assembleRelease
```

**Localização do arquivo:**
```
android/app/build/outputs/apk/release/app-release.apk
```

#### 4. Verificar Assinatura

```bash
jarsigner -verify -verbose android/app/build/outputs/apk/release/app-release.apk
```

---

## 📊 Comparação: Debug vs Release

| Aspecto | Debug | Release |
|---------|-------|---------|
| Tamanho | ~50-60 MB | ~30-40 MB |
| Performance | Mais lento | Mais rápido |
| Depuração | Habilitada | Desabilitada |
| Assinatura | Chave de debug | Chave de produção |
| Distribuição | Apenas teste | Google Play Store |
| Validade | Ilimitada | 10 anos |

---

## 🔧 Troubleshooting

### Erro: "Android SDK não encontrado"

```bash
# Configure a variável de ambiente
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

### Erro: "Java não encontrado"

```bash
# Instale Java 11
# macOS
brew install openjdk@11

# Ubuntu/Debian
sudo apt-get install openjdk-11-jdk

# Windows: Download de https://adoptopenjdk.net/
```

### Erro: "Gradle build failed"

```bash
# Limpar cache e reconstruir
cd android
./gradlew clean
./gradlew assembleDebug
```

### Telefone não aparece no Android Studio

1. Ative "Depuração USB" no telefone
2. Desconecte e reconecte o cabo USB
3. Autorize a conexão no telefone
4. Verifique: `adb devices`

---

## 📲 Instalar APK via ADB (Linha de Comando)

```bash
# Listar dispositivos conectados
adb devices

# Instalar APK
adb install android/app/build/outputs/apk/debug/app-debug.apk

# Desinstalar
adb uninstall com.ditadointeligente.app

# Executar aplicativo
adb shell am start -n com.ditadointeligente.app/.MainActivity
```

---

## 🎯 Próximos Passos

### Para Teste Local
1. Gere APK de Debug (Opção 1)
2. Instale em seu telefone
3. Teste todas as funcionalidades
4. Reporte bugs ou sugestões

### Para Distribuição
1. Gere APK Assinado (Opção 2)
2. Crie conta na Google Play Console
3. Siga o processo de publicação
4. Seu app estará disponível para download

---

## 📚 Recursos Adicionais

- **Android Studio Docs**: https://developer.android.com/studio/intro
- **Capacitor Docs**: https://capacitorjs.com/docs/android
- **Google Play Console**: https://play.google.com/console
- **Gradle Documentation**: https://gradle.org/

---

## ❓ Suporte

Se encontrar problemas:

1. Verifique os logs: `adb logcat`
2. Consulte a documentação do Capacitor
3. Verifique se todas as dependências estão instaladas
4. Tente limpar cache: `./gradlew clean`

---

**Versão do Guia**: 1.0  
**Data**: Março 2026  
**Aplicativo**: Ditado Inteligente v1.0
