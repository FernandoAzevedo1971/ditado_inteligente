# Guia de Compilação do APK - Ditado Inteligente

Este guia fornece instruções passo-a-passo para compilar o APK do "Ditado Inteligente" para Android 15 ou 16.

## Pré-requisitos

Antes de começar, certifique-se de ter instalado em sua máquina:

1. **Node.js** (versão 18+) - [Download](https://nodejs.org/)
2. **Java JDK** (versão 11+) - [Download](https://www.oracle.com/java/technologies/downloads/)
3. **Android SDK** - [Download Android Studio](https://developer.android.com/studio)
4. **Gradle** (incluído no Android Studio)

## Configuração do Ambiente

### 1. Instalar Android SDK

Após instalar o Android Studio:

```bash
# Abra o Android Studio e vá para:
# Tools → SDK Manager

# Instale os seguintes componentes:
# - Android SDK Platform 35 (Android 15)
# - Android SDK Platform 34 (Android 14)
# - Android SDK Build-Tools 35.0.0
# - Android Emulator (opcional)
# - Android SDK Command-line Tools
```

### 2. Configurar Variáveis de Ambiente

Adicione ao seu arquivo `.bashrc`, `.zshrc` ou equivalente:

```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools
export PATH=$PATH:$ANDROID_HOME/tools
export PATH=$PATH:$ANDROID_HOME/tools/bin
```

Depois execute:

```bash
source ~/.bashrc  # ou source ~/.zshrc
```

### 3. Verificar Instalação

```bash
# Verificar Java
java -version

# Verificar Android SDK
sdkmanager --list
```

## Compilação do APK

### Passo 1: Preparar o Projeto

```bash
cd /caminho/para/voice_text_corrector

# Instalar dependências (se necessário)
pnpm install

# Compilar build de produção
pnpm build

# Sincronizar com Capacitor
npx cap sync android
```

### Passo 2: Compilar APK de Debug

```bash
cd android

# Compilar APK de debug (mais rápido, para testes)
./gradlew assembleDebug

# O APK será gerado em:
# app/build/outputs/apk/debug/app-debug.apk
```

### Passo 3: Compilar APK de Release (Produção)

Para criar um APK pronto para distribuição:

```bash
cd android

# Compilar APK de release
./gradlew assembleRelease

# O APK será gerado em:
# app/build/outputs/apk/release/app-release-unsigned.apk
```

**Nota:** Para distribuir na Google Play Store, você precisará assinar o APK com uma chave privada. Veja a seção "Assinatura do APK" abaixo.

## Assinatura do APK (Produção)

### Criar Chave de Assinatura

```bash
# Gerar chave privada (execute uma única vez)
keytool -genkey -v -keystore ditado-inteligente.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias ditado-inteligente

# Você será solicitado a fornecer:
# - Senha para a keystore
# - Nome da organização
# - Localização
# - etc.
```

### Assinar o APK

```bash
# Assinar o APK de release
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 \
  -keystore ditado-inteligente.keystore \
  app/build/outputs/apk/release/app-release-unsigned.apk \
  ditado-inteligente

# Otimizar o APK (opcional)
zipalign -v 4 app/build/outputs/apk/release/app-release-unsigned.apk \
  DitadoInteligente.apk
```

## Instalação em Dispositivo Android

### Via ADB (Android Debug Bridge)

```bash
# Conectar dispositivo via USB e ativar "Depuração USB"

# Instalar APK de debug
adb install app/build/outputs/apk/debug/app-debug.apk

# Ou para APK de release
adb install DitadoInteligente.apk

# Verificar instalação
adb shell pm list packages | grep ditadointeligente
```

### Via Arquivo

1. Copie o arquivo APK para seu dispositivo Android
2. Abra o gerenciador de arquivos
3. Navegue até o arquivo APK
4. Toque para instalar
5. Permita a instalação de fontes desconhecidas (se solicitado)

## Testando o APK

### Teste em Emulador

```bash
# Abrir Android Emulator
emulator -avd Pixel_5_API_35 &

# Aguarde o emulador iniciar, depois instale:
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Teste em Dispositivo Real

1. Conecte seu dispositivo Android via USB
2. Ative "Depuração USB" em Configurações → Opções do Desenvolvedor
3. Execute: `adb install app/build/outputs/apk/debug/app-debug.apk`
4. Abra o aplicativo e teste:
   - Gravação de áudio
   - Transcrição
   - Correção de texto
   - Seleção de idioma
   - Histórico local

## Troubleshooting

### Erro: "ANDROID_HOME não está definido"

```bash
# Defina a variável:
export ANDROID_HOME=$HOME/Android/Sdk
```

### Erro: "Build-tools não encontrado"

```bash
# Instale via sdkmanager:
sdkmanager "build-tools;35.0.0"
sdkmanager "platforms;android-35"
```

### Erro: "Gradle build failed"

```bash
# Limpar cache e tentar novamente:
./gradlew clean
./gradlew assembleDebug
```

### Erro: "Permissão negada ao instalar"

```bash
# Desinstale a versão anterior:
adb uninstall com.ditadointeligente.app

# Depois instale novamente:
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Distribuição na Google Play Store

Para distribuir o aplicativo:

1. **Criar Conta Google Play Developer** - [Console Play](https://play.google.com/console)
2. **Assinar o APK** - Veja seção "Assinatura do APK"
3. **Criar Aplicativo** - Fornecer nome, descrição, screenshots
4. **Upload do APK** - Fazer upload do APK assinado
5. **Configurar Preço e Distribuição** - Definir países e preço
6. **Revisar e Publicar** - Google Play fará revisão (24-48 horas)

## Atualizações Futuras

Quando precisar atualizar o aplicativo:

```bash
# 1. Fazer alterações no código
# 2. Compilar novo build
pnpm build

# 3. Sincronizar com Capacitor
npx cap sync android

# 4. Compilar novo APK
cd android
./gradlew assembleRelease

# 5. Assinar e fazer upload para Play Store
```

## Recursos Adicionais

- [Documentação Capacitor](https://capacitorjs.com/docs/getting-started)
- [Documentação Android](https://developer.android.com/docs)
- [Google Play Console](https://play.google.com/console)
- [Android Studio](https://developer.android.com/studio)

## Suporte

Se encontrar problemas durante a compilação, consulte:

1. Logs do Gradle: `./gradlew assembleDebug --info`
2. Documentação oficial do Capacitor
3. Stack Overflow com tag `capacitor` ou `android`

---

**Versão:** 1.0  
**Data:** 26 de Março de 2026  
**Aplicativo:** Ditado Inteligente
