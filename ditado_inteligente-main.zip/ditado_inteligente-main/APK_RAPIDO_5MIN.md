# ⚡ Guia Rápido: Gerar APK em 5 Minutos

## 🎯 Objetivo
Instalar o Ditado Inteligente em seu telefone Android em 5 minutos.

---

## 📋 Pré-requisitos (2 minutos)

### 1. Instale Android Studio
- Download: https://developer.android.com/studio
- Siga o instalador padrão
- Deixe as configurações padrão

### 2. Conecte seu Telefone
- Conecte via USB
- Ative "Depuração USB":
  - Configurações → Sobre o telefone → Toque 7x em "Número da compilação"
  - Volte → Opções do desenvolvedor → Ative "Depuração USB"

---

## 🚀 Gerar e Instalar APK (3 minutos)

### No seu Computador

**Abra o Terminal/Prompt de Comando:**

```bash
# Navegue até a pasta do projeto
cd /caminho/para/voice_text_corrector

# Execute o script de compilação
./build-apk-debug.sh
```

**Ou manualmente:**

```bash
# Instalar dependências
pnpm install

# Compilar
pnpm build

# Sincronizar
npx cap sync android

# Gerar APK
cd android
./gradlew assembleDebug
cd ..
```

### Instalar no Telefone

**Opção A: Automático (Android Studio)**
1. Abra Android Studio
2. Clique em "Run" (Play button)
3. Selecione seu telefone
4. Pronto! ✅

**Opção B: Manual (ADB)**
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

**Opção C: Arquivo APK**
1. Copie `android/app/build/outputs/apk/debug/app-debug.apk` para seu telefone
2. Abra o gerenciador de arquivos
3. Toque no arquivo
4. Instale

---

## ✅ Pronto!

O aplicativo "Ditado Inteligente" agora está instalado em seu telefone.

**Teste:**
1. Abra o aplicativo
2. Toque no microfone azul
3. Fale algo
4. Veja a transcrição e correção

---

## 🆘 Se Algo Der Errado

### "Android SDK não encontrado"
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

### "Telefone não aparece"
1. Desconecte e reconecte o cabo
2. Autorize a conexão no telefone
3. Verifique: `adb devices`

### "Gradle build failed"
```bash
cd android
./gradlew clean
./gradlew assembleDebug
cd ..
```

---

## 📚 Próximas Etapas

- **Para Distribuição**: Veja `GERAR_APK_GUIA_COMPLETO.md`
- **Para Publicar na Play Store**: Crie conta em https://play.google.com/console

---

**Tempo Total: ~5 minutos** ⏱️
