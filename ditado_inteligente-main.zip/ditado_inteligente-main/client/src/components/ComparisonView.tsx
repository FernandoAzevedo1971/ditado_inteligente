import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useSystemTheme } from "@/hooks/useSystemTheme";
import { Copy, Check, ArrowLeft, Edit3, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import VoiceEditPanel from "./VoiceEditPanel";

interface ComparisonViewProps {
  originalText: string;
  correctedText: string;
  language: string;
  onClose: () => void;
}

export function ComparisonView({
  originalText,
  correctedText: initialCorrectedText,
  language,
  onClose,
}: ComparisonViewProps) {
  // Remover tema escuro - manter apenas fundo claro
  const [copied, setCopied] = useState(false);
  const [showEditPanel, setShowEditPanel] = useState(false);
  const [correctedText, setCorrectedText] = useState(initialCorrectedText);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      toast.success("Texto copiado com sucesso!");
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleTextUpdated = (finalText: string) => {
    setCorrectedText(finalText);
    setShowEditPanel(false);
    toast.success("Texto atualizado com sucesso!");
  };

  const shareToWhatsApp = () => {
    const text = encodeURIComponent(correctedText);
    const whatsappUrl = `https://wa.me/?text=${text}`;
    window.open(whatsappUrl, "_blank");
    toast.success("Abrindo WhatsApp...");
  };

  return (
    <div className="w-full min-h-screen flex flex-col items-center justify-start px-3 py-0 bg-gradient-to-br from-white via-blue-50 to-indigo-50">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="mb-2 flex items-center justify-between">
          <h1 className="text-3xl font-bold text-slate-900">Resultado</h1>
          <button
            onClick={onClose}
            className="p-1 rounded-lg transition-colors hover:bg-slate-100"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Comparison Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-2">
          {/* Original Text */}
          <Card className="p-3 shadow-lg border-0 rounded-xl bg-white">
            <h3 className="text-base font-semibold mb-1 text-slate-900">
              Texto Original
            </h3>
            <div className="p-2 rounded-lg border max-h-24 overflow-y-auto bg-slate-50 border-slate-200">
              <p className="text-sm whitespace-pre-wrap break-words leading-snug text-slate-700">
                {originalText}
              </p>
            </div>
          </Card>

          {/* Corrected Text */}
          <Card className="p-3 shadow-lg border-0 rounded-xl bg-white">
            <h3 className="text-base font-semibold mb-1 text-slate-900">
              Texto Corrigido
            </h3>
            <div className="p-2 rounded-lg border max-h-24 overflow-y-auto bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
              <p className="text-sm whitespace-pre-wrap break-words leading-snug text-slate-700">
                {correctedText}
              </p>
            </div>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2">
          <Button
            onClick={() => copyToClipboard(correctedText)}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white text-sm py-2 rounded-lg shadow-lg"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 mr-1" />
                Copiado!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 mr-1" />
                Copiar
              </>
            )}
          </Button>
          <Button
            onClick={() => setShowEditPanel(true)}
            className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white text-sm py-2 rounded-lg shadow-lg"
          >
            <>
              <Edit3 className="w-4 h-4 mr-1" />
              Editar com Voz
            </>
          </Button>
          <Button
            onClick={shareToWhatsApp}
            className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white text-sm py-2 rounded-lg shadow-lg"
          >
            <>
              <MessageCircle className="w-4 h-4 mr-1" />
              Compartilhar WhatsApp
            </>
          </Button>
          <Button
            onClick={onClose}
            className="w-full bg-gradient-to-r from-slate-600 to-slate-700 hover:from-slate-700 hover:to-slate-800 text-white text-sm py-2 rounded-lg shadow-lg"
          >
            Nova Gravação
          </Button>
        </div>
      </div>

      {/* Voice Edit Panel */}
      {showEditPanel && (
        <VoiceEditPanel
          correctedText={correctedText}
          language={language}
          onTextUpdated={handleTextUpdated}
          onClose={() => setShowEditPanel(false)}
        />
      )}
    </div>
  );
}

export default ComparisonView;
