# Compilar APK - Instruções Rápidas

## Resumo do que foi feito

✅ Capacitor instalado e configurado  
✅ Plataforma Android adicionada  
✅ Permissões configuradas (RECORD_AUDIO, INTERNET, etc.)  
✅ Build de produção compilado  
✅ Versão alvo: Android 15 (API 35) - compatível com Android 15 e 16  

## Próximos Passos (em sua máquina)

### 1. Instalar Pré-requisitos

```bash
# Instalar Android Studio
# https://developer.android.com/studio

# Após instalar, abra Android Studio e instale:
# - Android SDK Platform 35 (Android 15)
# - Android SDK Build-Tools 35.0.0
# - Android Emulator (opcional)
```

### 2. Configurar Variáveis de Ambiente

```bash
# No seu terminal, adicione ao .bashrc ou .zshrc:
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools
```

### 3. Compilar o APK

```bash
# Clone ou copie o projeto para sua máquina
cd voice_text_corrector

# Instale dependências
npm install
# ou
pnpm install

# Compile o build de produção
npm run build
# ou
pnpm build

# Sincronize com Capacitor
npx cap sync android

# Entre no diretório Android
cd android

# Compile o APK de debug (para testes)
./gradlew assembleDebug

# OU compile o APK de release (para produção)
./gradlew assembleRelease
```

### 4. Encontre o APK

**APK de Debug:**
```
android/app/build/outputs/apk/debug/app-debug.apk
```

**APK de Release:**
```
android/app/build/outputs/apk/release/app-release-unsigned.apk
```

### 5. Instale no Dispositivo

```bash
# Conecte seu dispositivo Android via USB
# Ative "Depuração USB" em Configurações → Opções do Desenvolvedor

# Instale o APK
adb install android/app/build/outputs/apk/debug/app-debug.apk

# Ou use o gerenciador de arquivos para instalar manualmente
```

## Estrutura do Projeto

```
voice_text_corrector/
├── capacitor.config.ts          ← Configuração do Capacitor
├── android/                     ← Código nativo Android
│   ├── app/build.gradle        ← Configuração do build
│   ├── variables.gradle         ← Versões do SDK
│   ├── gradlew                 ← Gradle wrapper
│   └── app/src/main/
│       ├── AndroidManifest.xml ← Permissões
│       └── assets/public/      ← Assets web
├── dist/public/                ← Build compilado
├── client/src/                 ← Código React
└── server/                     ← Código Node.js
```

## Configurações Aplicadas

| Configuração | Valor |
|---|---|
| App ID | com.ditadointeligente.app |
| App Name | Ditado Inteligente |
| Min SDK | 24 (Android 7.0) |
| Target SDK | 35 (Android 15) |
| Compile SDK | 35 (Android 15) |
| Permissões | RECORD_AUDIO, INTERNET, READ/WRITE_EXTERNAL_STORAGE |

## Permissões Configuradas

- ✅ `RECORD_AUDIO` - Para gravação de áudio
- ✅ `INTERNET` - Para chamadas de API
- ✅ `WRITE_EXTERNAL_STORAGE` - Para salvar arquivos
- ✅ `READ_EXTERNAL_STORAGE` - Para ler arquivos

## Troubleshooting

### Erro: "ANDROID_HOME não está definido"
```bash
export ANDROID_HOME=$HOME/Android/Sdk
```

### Erro: "Build-tools não encontrado"
```bash
# Instale via sdkmanager
sdkmanager "build-tools;35.0.0"
sdkmanager "platforms;android-35"
```

### Erro: "Gradle build failed"
```bash
cd android
./gradlew clean
./gradlew assembleDebug
```

## Para Mais Detalhes

Veja o arquivo completo: **GUIA_APK.md**

---

**Versão:** 1.0  
**Data:** 26 de Março de 2026  
**Aplicativo:** Ditado Inteligente
