import { invokeLLM } from "./_core/llm";
import { separateParagraphsByContext } from "./paragraphSeparation";

export type SupportedLanguage = "pt" | "en" | "es";

const CORRECTION_PROMPTS: Record<SupportedLanguage, { system: string; user: string }> = {
  pt: {
    system: `Você é um assistente especializado em correção de textos em português. Sua tarefa é:
1. Adicionar pontuação adequada (pontos, vírgulas, interrogações, exclamações)
2. Corrigir erros ortográficos e gramaticais
3. Manter o contexto e significado original do texto

IMPORTANTE: Não altere o significado ou contexto do texto, apenas corrija a forma.
NÃO adicione quebras de parágrafo - isso será feito separadamente.
Retorne APENAS o texto corrigido, sem explicações adicionais.`,
    user: `Por favor, corrija este texto em português:\n\n`,
  },
  en: {
    system: `You are a specialized text correction assistant for English. Your task is:
1. Add proper punctuation (periods, commas, question marks, exclamation marks)
2. Correct spelling and grammatical errors
3. Maintain the original context and meaning of the text

IMPORTANT: Do not change the meaning or context of the text, only correct the form.
DO NOT add paragraph breaks - this will be done separately.
Return ONLY the corrected text, without additional explanations.`,
    user: `Please correct this English text:\n\n`,
  },
  es: {
    system: `Eres un asistente especializado en corrección de textos en español. Tu tarea es:
1. Añadir puntuación adecuada (puntos, comas, signos de interrogación, signos de exclamación)
2. Corregir errores ortográficos y gramaticales
3. Mantener el contexto y significado original del texto

IMPORTANTE: No cambies el significado o contexto del texto, solo corrija la forma.
NO añadas saltos de párrafo - esto se hará por separado.
Devuelve SOLO el texto corregido, sin explicaciones adicionales.`,
    user: `Por favor, corrige este texto en español:\n\n`,
  },
};

export async function correctTextWithAI(originalText: string, language: SupportedLanguage = "pt"): Promise<string> {
  try {
    const prompts = CORRECTION_PROMPTS[language];

    // Step 1: Correct the text (punctuation, spelling, grammar)
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: prompts.system,
        },
        {
          role: "user",
          content: `${prompts.user}${originalText}`,
        },
      ],
    });

    if (!response.choices || !response.choices[0]?.message?.content) {
      throw new Error("Resposta inválida do LLM");
    }

    const content = response.choices[0].message.content;
    if (typeof content !== "string") {
      throw new Error("Resposta do LLM não é texto");
    }

    // Step 2: Separate paragraphs by context change
    const textWithParagraphs = await separateParagraphsByContext(content, language);

    return textWithParagraphs;
  } catch (error) {
    console.error("Error correcting text with AI:", error);
    throw new Error("Falha ao corrigir texto com IA");
  }
}
