import { transcribeAudio } from "./_core/voiceTranscription";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

export type SupportedLanguage = "pt" | "en" | "es";

const LANGUAGE_PROMPTS: Record<SupportedLanguage, string> = {
  pt: "Transcrever o texto ditado em português com precisão",
  en: "Transcribe the spoken text in English accurately",
  es: "Transcribir el texto hablado en español con precisión",
};

export async function transcribeAudioFile(audioBlob: Blob, language: SupportedLanguage = "pt"): Promise<string> {
  try {
    // Upload audio to S3
    const fileName = `audio-${nanoid()}.webm`;
    const buffer = await audioBlob.arrayBuffer();
    const { url: audioUrl } = await storagePut(
      `transcriptions/${fileName}`,
      Buffer.from(buffer),
      "audio/webm"
    );

    // Transcribe using Whisper API
    const result = await transcribeAudio({
      audioUrl,
      language,
      prompt: LANGUAGE_PROMPTS[language],
    });

    if ("error" in result) {
      throw new Error(result.error);
    }

    return result.text;
  } catch (error) {
    console.error("Error transcribing audio:", error);
    throw new Error("Falha ao transcrever áudio");
  }
}
