# Voice Text Corrector - TODO

## Funcionalidades Principais

### Fase 1: Estrutura e Planejamento
- [x] Inicializar projeto web com scaffold web-db-user
- [x] Criar schema do banco de dados para histórico de transcrições

### Fase 2: Interface de Gravação de Áudio
- [x] Implementar componente de gravação com Web Audio API
- [x] Criar botão de gravar/parar com estados visuais
- [x] Adicionar indicador visual de gravação ativa (animação)
- [x] Implementar visualizador de amplitude de áudio
- [ ] Testar gravação em dispositivos Android

### Fase 3: Upload e Transcrição
- [x] Implementar upload de áudio para S3
- [x] Integrar API Whisper para transcrição
- [x] Adicionar indicador de progresso durante transcrição
- [x] Exibir texto transcrito na interface

### Fase 4: Correção com IA
- [x] Integrar LLM para correção de pontuação e parágrafos
- [x] Implementar lógica de correção sem alterar contexto
- [x] Adicionar indicador de progresso durante correção
- [x] Exibir texto corrigido na interface

### Fase 5: Histórico e Comparação
- [x] Criar tabela de histórico no banco de dados
- [x] Implementar procedimento para salvar transcrições
- [x] Criar interface de comparação lado a lado
- [x] Implementar listagem de histórico com timestamps
- [x] Adicionar botão de copiar texto corrigido

### Fase 6: Testes e Otimizações
- [x] Testes unitários com Vitest (6 testes)
- [x] Testes de integração (6 testes)
- [x] Otimizações de performance mobile
- [x] Testes de responsividade em Android
- [x] Testes de fluxo completo end-to-end
- [x] Criar checkpoint final

## Arquitetura Técnica

### Banco de Dados
- Tabela `transcriptions`: id, userId, originalText, correctedText, createdAt, audioUrl

### Backend (tRPC)
- `transcriptions.create`: Salvar nova transcrição
- `transcriptions.list`: Listar histórico do usuário
- `transcriptions.delete`: Deletar transcrição
- `audio.transcribe`: Transcrever áudio com Whisper
- `text.correct`: Corrigir texto com LLM

### Frontend
- Componente `RecordingInterface`: Gravação e exibição
- Componente `ComparisonView`: Lado a lado
- Componente `HistoryList`: Histórico de transcrições
- Hook `useAudioRecorder`: Lógica de gravação

## Notas de Implementação
- Usar Web Audio API para gravação
- Armazenar áudio em S3 antes de transcrever
- Usar Whisper API para transcrição
- Usar LLM para correção mantendo contexto
- Interface totalmente responsiva para mobile
- Suportar português brasileiro


## Bugs Reportados

- [x] Erro ao iniciar gravação em Android 16 Chrome - investigar permissões e compatibilidade de API


## Correções Solicitadas

- [x] Reduzir tamanho da tela inicial para caber em uma visualização
- [x] Implementar transcrição automática ao parar de gravar
- [x] Remover duplicação de correção de IA
- [x] Remover histórico e banco de dados - simplificar para sessão única


## Melhorias de UI Solicitadas

- [x] Aumentar tamanho de letras e símbolos mantendo na mesma visualização
- [x] Remover marca "Feito com Manus" da tela inicial


## Redesign Inspirado em Speechify

- [x] Implementar paleta de cores azul/roxo
- [x] Redesenhar botão de gravação com animações
- [x] Layout centralizado com espaço em branco
- [x] Cards com sombras suaves
- [x] Tipografia aumentada (text-3xl/text-4xl)
- [x] Gradiente de fundo
- [x] Animações de ondas de som
- [x] Feedback visual melhorado


## Novas Funcionalidades

- [x] Implementar histórico local com localStorage (últimas 10 transcrições)
- [x] Criar seletor de idioma (português, inglês, espanhol)
- [x] Interface para visualizar histórico
- [x] Integrar idioma com transcrição e correção


## Mudanças Solicitadas

- [x] Renomear para "Ditado Inteligente" em toda interface
- [x] Implementar separação inteligente de parágrafos por contexto


## Otimizações de Tamanho

- [x] Reduzir fontes e espaçamentos proporcionalmente
- [x] Otimizar seletor de idioma (reduzir altura/padding)
- [x] Garantir que tudo cabe em uma única tela


## Bugs Reportados - Sessão 2

- [x] Remover inscrição "Made with Manus" que ainda aparece na tela inicial


## Nova Funcionalidade - Edição com Voz

- [x] Criar procedimento tRPC para aplicar correções de voz
- [x] Implementar componente de edição com gravação de correções
- [x] Adicionar botão "Editar com Voz" na interface
- [x] Testar fluxo completo de edição


## Bugs Reportados - Sessão 3

- [x] Edição por voz só funciona na segunda tentativa - corrigido com useEffect


## Otimizações de Tela de Resultados

- [x] Reduzir espaçamento entre títulos e textos
- [x] Reduzir altura das áreas de texto
- [x] Garantir que todos os botões caibam na mesma tela


## Melhorias de UX - Edição com Voz

- [x] Renomear botão "Editar" para "Editar com Voz"
- [x] Iniciar gravação automaticamente ao clicar no botão
- [x] Remover botão de microfone do painel de edição


## Melhorias de Feedback Visual

- [x] Adicionar overlay esmaecido durante transcrição e correção
- [x] Exibir mensagens de progresso destacadas ("Transcrevendo com IA...", "Corrigindo com IA...")
- [x] Animar transição entre mensagens de progresso


## Otimizações Finais

- [x] Remover espaço grande entre seletor de idioma e seção de resultados


## Geração de APK com Capacitor

- [x] Instalar Capacitor e dependências
- [x] Inicializar projeto Capacitor
- [x] Adicionar plataforma Android
- [x] Configurar permissões (RECORD_AUDIO, INTERNET, WRITE_EXTERNAL_STORAGE)
- [x] Configurar app.json com metadados
- [x] Compilar build de produção
- [ ] Gerar APK assinado (requer Android SDK em máquina local)
- [ ] Testar APK em Android 15 ou 16 (requer dispositivo ou emulador)


## Configuração do Nome do Aplicativo Android

- [x] Atualizar nome em strings.xml (já estava "Ditado Inteligente")
- [x] Atualizar nome em AndroidManifest.xml (referencia strings.xml)
- [x] Atualizar nome em capacitor.config.ts (já estava "Ditado Inteligente")
- [x] Sincronizar mudanças com Capacitor (não há mudanças necessárias)


## Otimizações de Espaçamento - Tela de Resultados

- [x] Reduzir espaço entre título "Texto Original" e campo de texto (mb-2 → mb-1)
- [x] Reduzir espaço entre título "Texto Corrigido" e campo de texto (mb-2 → mb-1)


## Melhorias de UX - Parar Gravação

- [x] Permitir clicar no ícone vermelho para parar gravação (além do texto)


## Aumento de Tamanho de Fontes

- [x] Aumentar tamanho das fontes mantendo tudo em uma tela
  - Títulos: text-2xl → text-3xl
  - Subtítulos: text-sm → text-base
  - Texto de conteúdo: text-xs → text-sm
  - Seletor de idioma: text-xs → text-sm


## Geração de APK Instalável

- [x] Criar guia completo de compilação (GERAR_APK_GUIA_COMPLETO.md)
- [x] Criar guia rápido 5 minutos (APK_RAPIDO_5MIN.md)
- [x] Criar script automatizado para APK Debug (build-apk-debug.sh)
- [x] Criar script automatizado para APK Release (build-apk-release.sh)
- [ ] Compilar APK Debug localmente (requer Android SDK em máquina local)
- [ ] Testar APK em dispositivo Android 15/16
- [ ] Gerar APK assinado para distribuição (requer chave de assinatura)


## Implementação de Tema Escuro

- [x] Criar hook useSystemTheme para detectar preferência do sistema
- [x] Implementar tema escuro em Home.tsx
- [x] Implementar tema escuro em RecordingInterface.tsx
- [x] Implementar tema escuro em ComparisonView.tsx
- [x] Implementar tema escuro em LanguageSelector.tsx
- [x] Testar tema escuro em diferentes telas (12 testes passando)


## Compilação de APK para Android

- [x] Criar guia passo-a-passo detalhado (COMPILAR_APK_PASSO_A_PASSO.md)
- [x] Criar script de instalação automática (install-apk.sh)
- [x] Criar guia rápido de 5 minutos (QUICK_START_APK.md)
- [ ] Compilar APK localmente (requer Android Studio em máquina local)
- [ ] Testar APK em dispositivo Android 15/16
- [ ] Gerar APK assinado para distribuição (opcional)


## Testes de Fundo Escuro

- [x] Testar fundo escuro mais profundo (preto/cinza muito escuro)
  - Fundo alterado: slate-900/800 → slate-950/900/black
  - Contraste mantido com texto branco
  - 12 testes passando sem regressões


## Tema Claro Permanente

- [x] Remover tema escuro automático
- [x] Manter apenas fundo claro em todos os componentes
  - Home.tsx: Removidas todas as condições de tema
  - Fundo: Gradiente claro (white/blue-50/indigo-50)
  - Texto: Sempre slate-900 (escuro)
  - 12 testes passando sem regressões


## Visualizador de Forma de Onda Sonora

- [x] Criar componente AudioWaveform com visualização em tempo real
  - 20 barras de forma de onda animadas
  - Ícone Volume2 (alto-falante) ao lado
  - Gradiente azul (blue-600 to blue-400)
  - Variação em tempo real com Web Audio API
- [x] Integrar visualizador em RecordingInterface (tela inicial)
  - Exibe durante gravação
  - Substitui visualização anterior de amplitude
- [x] Integrar visualizador em VoiceEditPanel (edição por voz)
  - Exibe durante gravação de correções
  - Mesmo estilo da tela inicial
- [x] Adicionar ícone de alto-falante ao lado das ondas
  - Volume2 icon em blue-600
- [x] Animar ondas conforme áudio é capturado
  - 12 testes passando sem regressões


## Redesenho de Visualizador - Barras Verticais

- [x] Reescrever AudioWaveform com barras verticais em vez de contorno
  - 40 barras verticais que variam de tamanho
  - Barras espelhadas (acima e abaixo da linha central)
  - Largura: 6px, espaçamento: 2px
- [x] Reduzir velocidade de movimento horizontal
  - Scroll offset: 0.3 pixels por frame (muito mais lento)
  - Movimento suave e contínuo
- [x] Testar visual em RecordingInterface e VoiceEditPanel
  - 12 testes passando sem regressões


## Otimização de Velocidade de Scroll

- [x] Reduzir velocidade de rolagem horizontal do visualizador (0.3 → 0.08)
  - Movimento muito mais lento e suave
  - 12 testes passando sem regressões
