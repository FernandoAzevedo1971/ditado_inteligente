# 📱 Android Studio para Iniciantes - Guia Completo

## 🎯 Objetivo
Compilar o aplicativo "Ditado Inteligente" e instalar no seu telefone Android.

**Tempo total: 20-30 minutos**

---

## ✅ Passo 1: Verificar se Android Studio está Instalado

### **Windows**
1. Clique no botão **Iniciar** (Windows)
2. Digite `Android Studio`
3. Se aparecer, clique para abrir
4. Aguarde carregar (pode levar 1-2 minutos)

### **macOS**
1. Abra o **Finder**
2. Clique em **Aplicativos** na barra lateral
3. Procure por **Android Studio**
4. Clique duas vezes para abrir

### **Linux**
1. Abra o terminal
2. Digite: `android-studio`
3. Pressione Enter

---

## 🔧 Passo 2: Configuração Inicial do Android Studio

Quando abrir pela primeira vez, verá uma tela de boas-vindas.

### **Tela 1: Welcome**
- Clique em **Next** (Próximo)

### **Tela 2: Install Type**
- Selecione **Standard** (padrão)
- Clique em **Next**

### **Tela 3: Select UI Theme**
- Escolha o tema que preferir (Light ou Dark)
- Clique em **Next**

### **Tela 4: SDK Components Setup**
- Deixe tudo marcado (padrão)
- Clique em **Next**

### **Tela 5: Emulator Settings**
- Deixe como está
- Clique em **Next**

### **Tela 6: Accept Licenses**
- Leia e clique em **I Agree** (Eu Concordo)
- Clique em **Next**
- Aguarde a instalação (pode levar 10-15 minutos)

### **Tela 7: Finish**
- Clique em **Finish**
- Aguarde o Android Studio carregar completamente

---

## 📁 Passo 3: Abrir o Projeto "Ditado Inteligente"

Agora você verá a tela inicial do Android Studio.

### **Opção A: Se vir "Welcome to Android Studio"**
1. Clique em **Open an Existing Project**

### **Opção B: Se vir "Projects"**
1. Clique em **Open**

### **Navegação**
1. Uma janela de pasta abrirá
2. Procure pela pasta `voice_text_corrector`
3. **Importante:** Abra a pasta `android` dentro de `voice_text_corrector`
   - Caminho: `voice_text_corrector/android`
4. Clique em **Open**

### **Aguarde o Carregamento**
- Android Studio vai processar o projeto
- Pode levar 3-5 minutos na primeira vez
- Verá mensagens de progresso na parte inferior

---

## 🔌 Passo 4: Conectar seu Telefone Android

### **No seu Telefone:**

1. **Ativar Modo de Desenvolvedor**
   - Vá para **Configurações**
   - Procure por **Sobre o Telefone**
   - Toque 7 vezes em **Número de Compilação**
   - Verá uma mensagem: "Você é desenvolvedor agora"

2. **Ativar Depuração USB**
   - Volte para **Configurações**
   - Procure por **Opções de Desenvolvedor** (agora visível)
   - Ative **Depuração USB**
   - Uma caixa de diálogo aparecerá no telefone
   - Toque em **OK** ou **Permitir**

3. **Conectar ao Computador**
   - Pegue um cabo USB
   - Conecte o telefone ao computador
   - Desbloqueie o telefone (coloque a senha/padrão)

### **No Android Studio:**
- Aguarde alguns segundos
- Na parte inferior direita, verá o nome do seu telefone
- Se não aparecer, clique em **Device Manager** (ícone de telefone)

---

## 🚀 Passo 5: Compilar o Aplicativo

Agora vem a parte fácil!

### **No Android Studio:**

1. **Localize o Menu Superior**
   - Veja a barra de menu no topo: File, Edit, View, etc.

2. **Clique em "Build"**
   - Procure por **Build** no menu superior
   - Clique em **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**

3. **Aguarde a Compilação**
   - Uma barra de progresso aparecerá na parte inferior
   - Pode levar 5-10 minutos
   - Verá mensagens como "Compiling...", "Linking...", etc.
   - **Não feche o Android Studio!**

4. **Sucesso!**
   - Quando terminar, verá uma mensagem: **"Build successful"**
   - Clique em **Locate** para encontrar o arquivo APK

---

## 📱 Passo 6: Instalar no Telefone

Após a compilação bem-sucedida:

### **Opção A: Instalação Automática (Recomendado)**

1. **Localize o Menu Superior**
   - Clique em **Run** no menu superior
   - Clique em **Run 'app'**

2. **Selecione o Telefone**
   - Uma janela aparecerá com seu telefone listado
   - Clique no seu telefone
   - Clique em **OK**

3. **Aguarde a Instalação**
   - Android Studio instalará automaticamente
   - Pode levar 1-2 minutos
   - Quando terminar, o app abrirá no seu telefone!

### **Opção B: Instalação Manual (Se a Opção A não funcionar)**

1. **Localize o Arquivo APK**
   - Após compilar, clique em **Locate** na mensagem de sucesso
   - Uma pasta abrirá mostrando o arquivo `app-debug.apk`

2. **Copie para o Telefone**
   - Clique com botão direito no arquivo
   - Clique em **Copiar**
   - Abra o gerenciador de arquivos do seu telefone
   - Cole o arquivo

3. **Instale no Telefone**
   - No telefone, procure pelo arquivo `app-debug.apk`
   - Toque no arquivo
   - Uma tela de instalação aparecerá
   - Clique em **Instalar**
   - Aguarde alguns segundos
   - Clique em **Abrir** quando terminar

---

## 🎉 Passo 7: Testar o Aplicativo

Seu app está instalado! Agora teste:

1. **Abra "Ditado Inteligente"** no seu telefone
2. **Faça login** com sua conta Manus (se necessário)
3. **Selecione o idioma** (Português, English, Español)
4. **Toque no microfone azul** para começar a gravar
5. **Fale algo claro**, por exemplo: "Olá, como você está?"
6. **Clique no ícone vermelho** para parar
7. **Veja o resultado** - seu texto transcrito e corrigido!

---

## ❓ Problemas Comuns

### **Problema 1: "Device not found"**
- Verifique se o telefone está conectado via USB
- Desbloqueie o telefone
- Toque em **OK** na caixa de diálogo de permissão que aparecer

### **Problema 2: "Build failed"**
- Feche o Android Studio
- Abra novamente
- Tente compilar de novo

### **Problema 3: "APK não instala"**
- Desinstale versões antigas do app
- Certifique-se de ter espaço no telefone
- Tente novamente

### **Problema 4: "Android Studio muito lento"**
- Feche outros programas
- Reinicie o computador
- Tente novamente

### **Problema 5: "Não consigo encontrar o projeto"**
- Certifique-se de abrir a pasta `android` dentro de `voice_text_corrector`
- Não abra apenas `voice_text_corrector`

---

## 🎯 Resumo Rápido

| Passo | O que fazer | Tempo |
|-------|------------|-------|
| 1 | Abrir Android Studio | 1 min |
| 2 | Configuração inicial | 15 min |
| 3 | Abrir projeto | 5 min |
| 4 | Conectar telefone | 2 min |
| 5 | Compilar (Build) | 10 min |
| 6 | Instalar no telefone | 2 min |
| 7 | Testar | 5 min |
| **Total** | | **40 min** |

---

## 📞 Precisa de Ajuda?

Se algo não funcionar:
1. Leia a seção "Problemas Comuns" acima
2. Reinicie o Android Studio
3. Reinicie o computador
4. Tente novamente

**Boa sorte! 🚀**
